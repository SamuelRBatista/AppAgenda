﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace testeNS.Models
{

    public class contexto : DbContext
    {
        public DbSet<cliente> Clientes { get; set; }
        public DbSet<filme> Filmes { get; set; }
        public DbSet<locacao> Locacaos{ get; set; }


    }
}