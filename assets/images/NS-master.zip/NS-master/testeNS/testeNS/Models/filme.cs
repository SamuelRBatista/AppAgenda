﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace testeNS.Models
{
    public class filme
    {
        [Key]
        public int Codigo { get; set; }
        [Required(ErrorMessage = "O nome do filme é obrigatório", AllowEmptyStrings = false)]
        public string Nome { get; set; }
        [Required(ErrorMessage = "O nome do diretor e obrigatório", AllowEmptyStrings = false)]
        public string Diretor { get; set; }
        [Required(ErrorMessage = "o ano de lançamento e obrigatório", AllowEmptyStrings = false)]
        public string Ano { get; set; }
        [Required(ErrorMessage = "A duração do filme é obrigatório", AllowEmptyStrings = false)]
        public string Duracao { get; set; }
        [Required(ErrorMessage = "A categoria do filme é obrigatório", AllowEmptyStrings = false)]
        public string Categoria { get; set; }
        [Required(ErrorMessage = "A descrição do filme é obrigatório", AllowEmptyStrings = false)]
        public string Descricao { get; set; }
    }
}