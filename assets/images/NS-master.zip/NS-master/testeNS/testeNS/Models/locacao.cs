﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace testeNS.Models
{
    public class locacao
    {
        [Key]
        public int Codigo { get; set; }
        [Required(ErrorMessage = "O nome do filme é obrigatório", AllowEmptyStrings = false)]
        public string Nome { get; set; }
        [Required(ErrorMessage = "O nome da categoria é obrigatório", AllowEmptyStrings = false)]
        public string Categoria { get; set; }
        [Required(ErrorMessage = "O valor é obrigatório", AllowEmptyStrings = false)]
        public string Valor { get; set; }
        [Required(ErrorMessage = "O valor de desconto é obrigatório", AllowEmptyStrings = false)]
        public string Desconto { get; set; }
       [Required(ErrorMessage = "O stutus disponivel  é obrigatório", AllowEmptyStrings = false)]
       public string Status { get; set; }
    }
}